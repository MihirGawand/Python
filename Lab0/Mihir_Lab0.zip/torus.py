#!/usr/bin/env python

import math
r = 3
R = 4
Vol_torus = 0.25*(math.pi**2)*(r+R)*((R-r)**2)
print(Vol_torus)


