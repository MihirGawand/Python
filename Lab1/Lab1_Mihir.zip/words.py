# -*- coding: utf-8 -*-
"""
Created on Fri Apr 13 09:07:07 2018

@author: sgmih
"""
#!/usr/bin/env python3

def letter_count(x,y):
    return x.lower().count(y)

if __name__ == '__main__':
    s = letter_count('MIHiR','i')
    print(s)
       
    
    
    
    
    
    
    
    
    
    
    
    
    