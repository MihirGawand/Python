# -*- coding: utf-8 -*-


#!/usr/bin/env python3

import math

class Complex():
    def __init__(self, r = 0, i = 0):
        self.re = r
        self.im = i

  
    def __str__(self):
        if self.im < 0:
            return '({0} '.format(self.re) + '- {0}i)'.format(abs(self.im))        
        else:        
            return '({0} '.format(self.re) + '+ {0}i)'.format(self.im)
        
    def __repr__(self):
        return self.__str__()

    def __add__(self,other):    #Add
        if isinstance(other,(float,int)):
            return Complex(self. re + other,
                           self.im)
        else:
            return Complex(self. re + other.re,
                           self.im + other.im)  
            
            
    def __radd__(self,other):
        return self + other
    
            
    def __sub__(self,other):
        if isinstance(other,(float,int)):
            return Complex(self.re - other, self.im)
        else:
            return Complex(self.re - other.re,
                           self.im - other.im)
            
            
    def __rsub__(self,other):
        return Complex(other) - self
    
    
    def __invert__(self):
        return Complex(self.re, -self.im)
    
    def __neg__(self):
        return Complex(-self.re, -self.im)
    
    def __mul__(self,other):
        if isinstance(other,(float,int)):
            return Complex(self.re*other, self.im*other)
        else:
            return Complex(self.re*other.re - self.im*other.im, self.re*other.im + self.im*other.re)
    
    def __rmul__(self,other):
        if isinstance(other,(float,int)):
            return Complex(other)*self


    def __truediv__(self,other):
        try:
            if isinstance(other,(float, int)):
                return Complex(self.re/other, self.im/other)
            else:
                denom = float(other.re**2 + other.im**2)
                print(denom)
                return Complex(((self.re*other.re) + (self.im*other.im))/denom, ((self.im*other.re) - (self.re*other.im))/denom)
        except ZeroDivisionError as e:
            print(e)    
            return None 
    
    def __rtruediv__(self,other):
        try:
            if isinstance(other,(float, int)):
                return Complex(other)/self
        except ZeroDivisionError as e:
            print(e)
            return None
            
            
    
def sqrt(a):
    if type (a) == Complex:
        if (a.im == 0):
            return Complex(math.sqrt(a.re), 0)
        else:
            real = math.sqrt((a.re + math.sqrt(a.re**2 + a.im**2))/2)
            if a.im > 0:
                imag = math.sqrt((-a.re + math.sqrt(a.re**2 + a.im**2))/2)
                return Complex(real,imag)
            elif a.im < 0:
                imag = -math.sqrt((-a.re + math.sqrt(a.re**2 + a.im**2))/2)
                return Complex(real,imag)
    else:
        return math.sqrt(a)

if __name__ == '__main__':
#    a = Complex(3,0)
    b = Complex(4,3)
    a = sqrt(5)

    """ 
    I have wrote a separate test code file for this complex.py named as test_complex which tests cases
    for both complex.py and roots.py. Please run that file which will show you the unittest module
    that I have written for both the codes
    
    Thank you,
    Mihir
    """"
    
    
    
    
    

    
    
    